$(document).ready(function(){
    
});

$("img").click(function(){
    var newimg = $(this).attr("cat");
    var oldimg = $(this).attr("src");
    $(this).attr("cat",oldimg);
    $(this).attr("src",newimg);
});